#include <array>
#include <chrono>
#include <iostream>

using namespace std::chrono;

const unsigned STEPS = 1e8;      // repetitions

std::array<char, 1 << 28> bytes; // 256Mx1B = 256MB

// be careful... STEPS < bytes.size()!!!

void test(unsigned increment)
{
	auto start = high_resolution_clock::now();

	for (unsigned step = 0; step < STEPS; ++step)
		bytes[(step * increment) & (bytes.size() - 1)] ^= 1;  //El & bytes... sirve para que no te pases de memoria y vuelvas al principio

	auto stop = high_resolution_clock::now();

	std::cout << duration_cast<milliseconds>(stop - start).count() << "ms" << std::endl;
}

int main()
{
	for (unsigned i = 1; i <= 1024; i <<= 1)
	{
		std::cout << "i = " << i << " \t t = ";
		test(i);
	}
}
